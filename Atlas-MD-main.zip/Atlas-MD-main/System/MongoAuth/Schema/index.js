module.exports = {
    sessionSchema: require("./SessionSchema"),
  };